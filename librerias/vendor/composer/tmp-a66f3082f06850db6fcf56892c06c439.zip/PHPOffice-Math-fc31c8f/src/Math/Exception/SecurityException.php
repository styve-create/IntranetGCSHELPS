<?php

namespace PhpOffice\Math\Exception;

class SecurityException extends MathException
{
}
