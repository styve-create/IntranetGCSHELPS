<?php

namespace PhpOffice\Math\Exception;

class NotImplementedException extends MathException
{
}
