<?php

namespace PhpOffice\Math\Element;

abstract class AbstractElement
{
}
